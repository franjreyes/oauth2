package com.example.demo.service.model;

import lombok.Data;

@Data
public class BaseEntity {

    protected Long id;
    protected String name;
}
