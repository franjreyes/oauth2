package com.example.demo.v1.dto;

public class MonkeyDTO {
}
